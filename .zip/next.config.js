module.exports = {
	target: 'serverless'
}
