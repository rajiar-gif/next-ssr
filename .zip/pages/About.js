import Layout from "../components/Layout";

export default function About() {
	return (
		<Layout>
			<p>This is the about page</p>
			<p>this for testing</p>
		</Layout>
	)
};
